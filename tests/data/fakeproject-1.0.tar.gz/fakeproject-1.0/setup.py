from setuptools import setup

setup(
    name='fakeproject',
    version='1.0',
    description='A fake Python project',
    packages=["fakeproject"],
)
