from setuptools import setup

setup(name="dummyproject", version="0.23ubuntu1")
