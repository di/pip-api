from setuptools import setup

setup(
    name='dummyproject',
    version='0.0.1',
    description='A dummy Python project',
    packages=["dummyproject"],
)
